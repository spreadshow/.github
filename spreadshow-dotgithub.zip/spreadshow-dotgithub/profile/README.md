# Spreadshow

**Spreadsheets and presentations had a fight. Spreadshow made peace.**

Spreadshow is an open-source live data workbook. Connect your sources, query them with SQL or a visual query builder, and present the results as interactive slides, all in one file that diffs cleanly in git.

Slides are live views on your data, always up to date and open to exploration.

## Why Spreadshow

- **Live.** Sheets and slides point to the source, not to a copy.
- **SQL-first, for everyone.** Readable SQL for people who know it; a query builder that generates visible SQL for everyone else.
- **Open.** Text-based, git-friendly file format, an embedded query engine, and extensible connectors.

## Who it is for

- **Small businesses:** import a CSV, ask questions, show the numbers.
- **Large organizations:** self-service on company data, with the permissions of the underlying database.

## Status

Early stage. We are defining the architecture and the MVP.

## Get involved

- Read the [contributing guide](https://github.com/spreadshow/.github/blob/main/CONTRIBUTING.md)
- Open an issue or start a discussion in the main repository
- Star the repo to follow progress
